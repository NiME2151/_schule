
const handleClick = () => {
    let input = document.getElementById("input");
    console.log(input.value);
}